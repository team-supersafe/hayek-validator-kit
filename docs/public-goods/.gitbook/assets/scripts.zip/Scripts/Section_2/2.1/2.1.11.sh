#!/usr/bin/env bash
{
    # Function to check the installation status of cups
    check_cups_installed() {
        dpkg-query -s cups &>/dev/null && echo "cups is installed"
    }

    # Function to check if the cups is enabled or active
    check_cups_service_status() {
        enabled=$(systemctl is-enabled cups.socket cups.service 2>/dev/null | grep 'enabled')
        active=$(systemctl is-active cups.socket cups.service 2>/dev/null | grep '^active')

        if [[ -n "$enabled" ]]; then
            l_output2+=( "- cups is enabled")
        else
            l_output+=( "- cups is not enabled")
        fi

        if [[ -n "$active" ]]; then
            l_output2+=( "- cups is active")
        else
            l_output+=( "- cups is not activate")
        fi
    }

    # Arrays to store correct and incorrect results
    l_output=()
    l_output2=()

    # Check if cups is installed
    result=$(check_cups_installed)

    # If cups is installed, check the service status
    if [[ "$result" == "cups is installed" ]]; then
        check_cups_service_status
    fi

    # Check if cups is installed
    if [[ "$result" == "cups is installed" ]]; then
        l_output2+=("- $result")
    else
       l_output+=("- cups is not installed")
    fi

 # Report results in plain text format
    if [ ${#l_output2[@]} -le 0 ]; then
        echo "====== Audit Report ======"
        echo "Audit Result: PASS"
        echo "--------------------------"
        echo "Correct Settings:"
        printf '%s\n' "${l_output[@]}"
    else
        echo "====== Audit Report ======"
        echo "Audit Result: FAIL"
        echo "--------------------------"
        echo "Correct Settings:"
        printf '%s\n' "${l_output[@]}"
        echo "--------------------------"
        echo "Reason(s) for Failure:"
        printf '%s\n' "${l_output2[@]}"
    fi
}