#!/usr/bin/env bash

a_output=()
a_output2=()

# Check if UFW is in use first
if ! {command -v ufw &>/dev/null && systemctl is-active --quiet ufw; } ; then
    audit_result="SKIP"
    a_output+=("- UFW is not in use, audit skipped")
else
    # Capture UFW rules output
    mapfile -t rules < <(ufw status numbered)
    audit_result="MANUAL"
    a_output+=("- UFW rules for manual review of outbound connections:")
    for rule in "${rules[@]}"; do
        a_output+=("- $rule")
    done
fi

# Output result in text format
echo "====== Audit Report ======"
echo "Audit Result: $audit_result"
echo "--------------------------"
echo "Correct Settings:"
if [ ${#a_output[@]} -eq 0 ]; then
    echo "(none)"
else
    printf '%s\n' "${a_output[@]}"
fi
